public interface Reportable {

    public void report();

}
