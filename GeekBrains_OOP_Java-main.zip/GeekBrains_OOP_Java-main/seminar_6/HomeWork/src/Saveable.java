public interface Saveable {

    public void save();

}
