package model;

public interface FileOperation {

    String readText();
    void saveText(String text);

}
