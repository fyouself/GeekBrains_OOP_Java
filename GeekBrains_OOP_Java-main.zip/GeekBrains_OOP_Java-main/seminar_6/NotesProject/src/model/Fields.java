package model;

public enum Fields {
    HEAD,
    TEXT
}
