package views;

public enum Commands {
    HELP,
    READ,
    CREATE,
    UPDATE,
    LIST,
    DELETE,
    EXIT
}
