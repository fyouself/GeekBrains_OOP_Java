package Weapons;// Создать интерфейс Weapon с методом damage(), который будет показывать наносимый урон

public interface Weaponable {
    
    public int damage();
}
