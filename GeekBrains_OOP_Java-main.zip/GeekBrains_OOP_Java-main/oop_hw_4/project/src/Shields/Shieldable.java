package Shields;

public interface Shieldable {

    public int sizeShield();
    public int armor();
    public Shield getShield();

}
