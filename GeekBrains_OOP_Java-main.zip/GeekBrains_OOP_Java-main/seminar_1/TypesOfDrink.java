public enum TypesOfDrink {

    JUICE,
    MINERALWATER,
    SODA,
    WATER,
    COLDTEA,
    MILK

}
