public interface Runable {
    public int speedOfRun();
}
