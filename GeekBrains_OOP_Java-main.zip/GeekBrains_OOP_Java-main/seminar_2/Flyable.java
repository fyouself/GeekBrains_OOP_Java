public interface Flyable {

    public int speedOfFly();

}
