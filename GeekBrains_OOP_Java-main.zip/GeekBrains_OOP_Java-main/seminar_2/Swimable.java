public interface Swimable {

    public int speedOfSwim();

}
