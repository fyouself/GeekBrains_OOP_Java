public class Radio implements Speakable{

    @Override
    public String say() {
        return "Good morning";
    }
}
