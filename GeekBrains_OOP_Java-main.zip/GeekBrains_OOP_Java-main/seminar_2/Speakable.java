public interface Speakable {

    public String say();

}
