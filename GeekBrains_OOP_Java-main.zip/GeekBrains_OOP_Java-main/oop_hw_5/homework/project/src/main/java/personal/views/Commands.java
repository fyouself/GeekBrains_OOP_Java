package personal.views;

public enum Commands {
    NONE,
    READ,
    CREATE,
    UPDATE,
    LIST,
    HELP,
    DELETE,
    EXIT
}
