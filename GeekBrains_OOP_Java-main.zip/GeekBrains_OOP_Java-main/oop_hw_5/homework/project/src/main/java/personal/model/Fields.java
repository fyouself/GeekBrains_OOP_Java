package personal.model;

public enum Fields {
    NAME,
    FIO,
    TELEPHONE
}
