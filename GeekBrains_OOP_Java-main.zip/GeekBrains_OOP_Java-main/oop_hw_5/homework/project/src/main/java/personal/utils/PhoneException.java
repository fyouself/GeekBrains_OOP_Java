package personal.utils;

public class PhoneException extends Exception {
    public PhoneException(String msg) {
        super(msg);
    }
}
